   <!-- ======= Sidebar ======= -->
   <aside id="sidebar" class="sidebar">

       <ul class="sidebar-nav" id="sidebar-nav">

           <li class="nav-item">
               <a class="nav-link" href="/dashboard">
                   <i class="bi bi-grid"></i>
                   <span>Dashboard</span>
               </a>
           </li><!-- End Dashboard Nav -->

           <li class="nav-item">
               <a class="nav-link" href="/project">
                   <i class="bi bi-folder"></i><span>Data Project</span>
               </a>
           </li>
           <li class="nav-item">
               <a class="nav-link" href="/">
                   <i class="bi bi-envelope"></i><span>Data Message</span>
               </a>
           </li>

       </ul>

   </aside><!-- End Sidebar-->
<?php /**PATH C:\xamppp\htdocs\portfolioNew\resources\views/dashboards/layouts/sidebar.blade.php ENDPATH**/ ?>