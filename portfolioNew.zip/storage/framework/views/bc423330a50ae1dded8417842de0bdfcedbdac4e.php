
<?php $__env->startSection('container'); ?>
    <div class="pagetitle">
        <h1><?php echo e($title); ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <div class="card-body">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">

                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>

            </div>
        <?php endif; ?>
        <h5 class="card-title"><?php echo e($title); ?> </h5>

        <!-- Floating Labels Form -->
        <form action="/project" method="post" class="row g-3" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id_admin" value="<?php echo e($dataProject->id); ?>">
            <div class="col-md-5">
                <div class="form-floating mb-3">
                    <select name="jenis_project" class="form-select" id="floatingSelect" aria-label="State"
                        value=<?php echo e(old('jenis_project')); ?>>
                        <option value="Web" selected>Web</option>
                        <option value="Android">Android</option>
                        <option value="Desktop">Desktop</option>
                    </select>
                    <label for="floatingSelect">Jenis Project</label>
                </div>
            </div>
            <div class="col-md-5">
                <div class="form-floating">
                    <input name="nama_project" type="text" class="form-control" id="floatingName"
                        placeholder="Nama Project" value="<?php echo e(old('nama_project')); ?>" required>
                    <label for="floatingName">Nama Project</label>
                </div>
            </div>
            <div class="col-md-7">
                <div class="form-floating">
                    <input name="dibuat_dengan" type="text" class="form-control" id="floatingEmail"
                        placeholder="Dibuat Dengan" value="<?php echo e(old('dibuat_dengan')); ?>" required>
                    <label for="floatingEmail">Dibuat Dengan</label>
                </div>
            </div>
            <div class="col-md-8">

                <label for="formFile" class="col-sm-2 col-form-label">Image Upload</label>
                <div class="col-md-10">
                    <input name="images[]" accept="image/*" class="form-control" type="file" id="formFile" multiple>
                </div>

            </div>
            <div class="col-md-7">
                <div class="form-floating">
                    <textarea name="keterangan" class="form-control" placeholder="Keterangan" id="floatingTextarea" style="height: 100px;"
                        value="<?php echo e(old('keterangan')); ?>" required></textarea>
                    <label for="floatingTextarea">Keterangan</label>
                </div>

                <div class="d-flex justify-content-end mt-2">
                    <button name="btnSimpan" type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>


        </form><!-- End floating Labels Form -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboards.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\portfolioNew\resources\views/dashboards/projects/add.blade.php ENDPATH**/ ?>