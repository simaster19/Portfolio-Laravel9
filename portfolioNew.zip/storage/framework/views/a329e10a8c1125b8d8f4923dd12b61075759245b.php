 <!-- ======= Footer ======= -->
 <footer class="footer bg-black text-light text-center mb-0" role="contentinfo">
     <div class="container">
         <div class="row d-flex">
             <p class="mb-1">
                 &copy; Copyright MyPortfolio. All Rights Reserved - 2023
             </p>
         </div>
         <div class="social">
             <a href="https://instagram.com/simaster19"><span class="bi bi-instagram"></span></a>
             <a
                 href="https://api.whatsapp.com/send/?phone=6289635032061&text=Saya Sudah Melihat Web Portfolio Anda,%0ADan Saya Ingin Menggunakan Jasa Servise Anda"><span
                     class="bi bi-whatsapp"></span></a>
         </div>
     </div>
 </footer>

 <!-- Button Top -->
 <!-- <div class="buttonTop">
  <a href="#" class="back-to-top d-flex bg-danger"
    ><i class="bi bi-arrow-up-short"></i
  ></a>
</div> -->
<?php /**PATH C:\xamppp\htdocs\portfolioNew\resources\views/layouts/footer.blade.php ENDPATH**/ ?>