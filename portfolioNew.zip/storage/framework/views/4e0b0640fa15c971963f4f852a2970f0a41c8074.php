
<?php $__env->startSection('container'); ?>
    <section class="section">
        <div class="container">
            <div class="row mb-4 align-items-center">
                <div class="col-md-6" data-aos="fade-up">
                    <h2><?php echo e($dataProject->nama_project); ?></h2>

                </div>
            </div>
        </div>

        <div class="site-section pb-0">
            <div class="container">
                <div class="row align-items-stretch">

                    <div class="col-md-8" data-aos="fade-up">
                        <?php $__currentLoopData = $dataProject->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('project-images/' . $image->gambar)); ?>" alt="Image" class="img-fluid">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-md-3 ml-auto" data-aos="fade-up" data-aos-delay="100">
                        <div class="sticky-content stop">
                            <h5 class="mt-2 h5"><?php echo e($dataProject->jenis_project); ?></h5>
                            <div class="mb-4">
                                <p>
                                    <?php echo e($dataProject->keterangan); ?>

                                </p>
                            </div>
                            <h5 class="h5 mb-3">What I did</h5>
                            <ul class="list-unstyled list-line mb-1">
                                <?php
                                $lists = explode(',', $dataProject->dibuat_dengan);
                                ?>
                                <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($list); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\portfolioNew\resources\views/detail.blade.php ENDPATH**/ ?>