
<?php $__env->startSection('container'); ?>
    <div class="pagetitle">
        <h1><?php echo e($title); ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active"><?php echo e($title); ?></li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <!-- Default Card -->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($title . ' ' . $dataProject->nama_project); ?></h5>
            <p><?php echo e($dataProject->keterangan); ?></p>

            <?php $__currentLoopData = $dataProject->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(asset('project-images/' . $image['gambar'])); ?>" class="card-img-top"
                        alt="<?php echo e($image['gambar']); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div><!-- End Default Card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboards.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\portfolioNew\resources\views/dashboards/projects/detail.blade.php ENDPATH**/ ?>