<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Administrator</title>



    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">


    <!-- Template Main CSS File -->
    

</head>

<body>


    <main id="main" class="main">

        <?php echo $__env->yieldContent('container'); ?>

    </main><!-- End #main -->



    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/quill/quill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/tinymce/tinymce.min.js')); ?>"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(asset('js/main2.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xamppp\htdocs\portfolioNew\resources\views/dashboards/layouts/mainlogin.blade.php ENDPATH**/ ?>